from flask import Flask, request

app = Flask(__name__)

@app.route('/data', methods=['POST'])
def receive_data():
    data = request.get_json()
    print("Received:", data)
    return {"status": "ok"}

if __name__ == '__main__':
    app.run(port=5000)
