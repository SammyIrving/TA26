import requests

data = {"value": 42}
res = requests.post("http://localhost:5000/data", json=data)
print(res.json())
