import requests

SERVER_URL = "http://localhost:5000" 

def post_value(endpoint: str, key: str, value):
    try:
        response = requests.post(
            f"{SERVER_URL}/{endpoint}",
            json={key: value},
            timeout=3
        )
        return response.text
    except requests.exceptions.RequestException as e:
        print(f"POST Error to /{endpoint}:", e)
        return None

def get_value(endpoint: str, key: str):
    try:
        response = requests.get(f"{SERVER_URL}/{endpoint}", timeout=3)
        if response.status_code == 200:
            return response.json().get(key, "")
        else:
            print(f"GET Error from /{endpoint}: Status code", response.status_code)
            return None
    except requests.exceptions.RequestException as e:
        print(f"GET Error from /{endpoint}:", e)
        return None
