# server.py
from flask import Flask, request

app = Flask(__name__)

@app.route('/nilai_flow', methods=['POST'])
def receive_flow():
    data = request.get_json()
    print("Received:", data)
    return "Data received", 200

if __name__ == '__main__':
    app.run(port=5000)
