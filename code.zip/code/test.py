# server.py
from flask import Flask, request, jsonify

app = Flask(__name__)

# Store nilai_flow globally
nilai_flow = 31

@app.route('/nilai_flow', methods=['POST'])
def receive_flow():
    global nilai_flow
    data = request.get_json()
    print("Received:", data)
    nilai_flow = data.get("nilai_flow", nilai_flow)
    return "Data received", 200

@app.route('/nilai_flow', methods=['GET'])
def send_flow():
    return jsonify({"nilai_flow": nilai_flow})

if __name__ == '__main__':
    app.run(port=5000)
