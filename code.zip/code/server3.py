from flask import Flask, request, jsonify

app = Flask(__name__)

# Global variable to store nilai_flow
nilai_flow = None

@app.route('/nilai_flow', methods=['POST'])
def receive_flow():
    global nilai_flow
    data = request.get_json()
    nilai_flow = data.get("nilai_flow", None)
    print(f"Received nilai_flow: {nilai_flow}")
    return jsonify({"message": "Data received"}), 200

@app.route('/nilai_flow', methods=['GET'])
def send_flow():
    global nilai_flow
    if nilai_flow is not None:
        return jsonify({"nilai_flow": nilai_flow}), 200
    else:
        return jsonify({"error": "No data available"}), 404

if __name__ == '__main__':
    app.run(port=5000)
