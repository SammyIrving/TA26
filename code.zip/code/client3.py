import requests
import time

# Send POST request
post_data = {"nilai_flow": 42}
response = requests.post("http://localhost:5000/nilai_flow", json=post_data)

if response.status_code == 200:
    print("POST successful:", response.json())
else:
    print("POST failed:", response.status_code)

# Wait a bit before GET
time.sleep(1)

# Send GET request
response = requests.get("http://localhost:5000/nilai_flow")

if response.status_code == 200:
    data = response.json()
    print("GET successful, nilai_flow =", data.get("nilai_flow"))
else:
    print("GET failed:", response.status_code)
