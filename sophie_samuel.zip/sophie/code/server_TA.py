from flask import Flask, request, jsonify
import signal
import sys
import socket

app = Flask(__name__)

# Global variable to store nilai_flow
nilai_flow = None
current_flow_value = None
flow_acc = None
suture_acc = None
duration = None
evaluation = None

# Create a socket with SO_REUSEADDR to allow immediate reuse of the port
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
port = 5000  # Default port
app = Flask(__name__)


@app.route('/nilai_flow', methods=['POST'])
def post_flow():
    global nilai_flow
    data = request.get_json()
    nilai_flow = data.get("nilai_flow", None)
    print(f"Received nilai_flow: {nilai_flow}")
    return jsonify({"message": "Data received"}), 200

@app.route('/nilai_flow', methods=['GET'])
def get_flow():
    global nilai_flow
    if nilai_flow is not None:
        return jsonify({"nilai_flow": nilai_flow}), 200
    else:
        return jsonify({"error": "No data available"}), 404

@app.route('/current_flow', methods=['POST'])
def post_current_flow():
    global current_flow_value
    flow = request.form.get('current_flow')
    if flow:
        current_flow_value = flow
        print(f"Flow terkini diterima: {flow} ml/min")
        return "Data diterima", 200
    else:
        return "Data tidak lengkap", 400

@app.route('/current_flow', methods=['GET'])
def get_current_flow():
    global current_flow_value
    if current_flow_value is not None:
        return jsonify({"current_flow": current_flow_value}), 200
    else:
        return jsonify({"error": "No data available"}), 404


@app.route('/flow_acc', methods=['POST'])
def post_flow_acc():
    global flow_acc
    data = request.get_json()
    flow_acc = data.get("flow_acc", None)
    print(f"Received flow_acc: {flow_acc}")
    return jsonify({"message": "Flow accuracy received"}), 200

@app.route('/flow_acc', methods=['GET'])
def get_flow_acc():
    global flow_acc
    if flow_acc is not None:
        return jsonify({"flow_acc": flow_acc}), 200
    else:
        return jsonify({"error": "No data available"}), 404

@app.route('/suture_acc', methods=['POST'])
def post_suture_acc():
    global suture_acc
    data = request.get_json()
    suture_acc = data.get("suture_acc", None)
    print(f"Received suture_acc: {suture_acc}")
    return jsonify({"message": "Suture accuracy received"}), 200

@app.route('/suture_acc', methods=['GET'])
def get_suture_acc():
    global suture_acc
    if suture_acc is not None:
        return jsonify({"suture_acc": suture_acc}), 200
    else:
        return jsonify({"error": "No data available"}), 404

@app.route('/duration', methods=['POST'])
def post_duration():
    global duration
    data = request.get_json()
    duration = data.get("duration", None)
    print(f"Received duration: {duration}")
    return jsonify({"message": "Duration received"}), 200

@app.route('/duration', methods=['GET'])
def get_duration():
    global duration
    if duration is not None:
        return jsonify({"duration": duration}), 200
    else:
        return jsonify({"error": "No data available"}), 404

@app.route('/evaluation', methods=['POST'])
def post_evaluation():
    global evaluation
    data = request.get_json()
    evaluation = data.get("evaluation", None)
    print(f"Received evaluation: {evaluation}")
    return jsonify({"message": "Evaluation received"}), 200

@app.route('/evaluation', methods=['GET'])
def get_evaluation():
    global evaluation
    if evaluation is not None:
        return jsonify({"evaluation": evaluation}), 200
    else:
        return jsonify({"error": "No data available"}), 404


def shutdown_server(signum, frame):
    """Handle shutdown signals to ensure the server stops and releases the port."""
    print(f"Received signal {signum}, shutting down server...")
    # Close the socket to release the port
    if 'server_socket' in globals():
        server_socket.close()
        print(f"Port {port} released.")
    sys.exit(0)

if __name__ == '__main__':
    # Register signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, shutdown_server)
    signal.signal(signal.SIGTERM, shutdown_server)

    try:
        # Bind the socket to the port
        server_socket.bind(('0.0.0.0', port))
        print(f"Server started on port {port}")
        app.run(host='0.0.0.0', port=port, debug=False, use_reloader=False)
    except Exception as e:
        print(f"Failed to start server: {e}")
        shutdown_server(0, None)
    finally:
        shutdown_server(0, None)
